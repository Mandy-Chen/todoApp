import { combineReducers } from 'redux';
import AddTodoReducer from './AddTodoReducer'


export const reducer=combineReducers(
    {AddTodoReducer}
)


